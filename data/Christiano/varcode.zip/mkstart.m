function avec=svsz;

avec=2*randn(26,1);
avec([1 8 12 14 19 23 26]) = abs(avec([1 8 12 14 19 23 26]));
